package meea.licenta.greeny;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GreenyApplicationTests {

	@Test
	void contextLoads() {
	}

}
